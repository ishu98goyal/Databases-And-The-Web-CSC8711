How to Excute this App: 

    python loaddata.py teams.dat games.dat

    python baseball.py 

